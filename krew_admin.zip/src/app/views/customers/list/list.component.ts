import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-customers',
  templateUrl: './list.component.html'  
})
export class ListComponent implements OnInit {

  constructor() { alert('hi')}

  ngOnInit() {

  }

}
