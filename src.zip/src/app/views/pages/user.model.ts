export class User {
    id:String ;
    name:String;
}